﻿**Práctica Windows.       Instalación, administración y configuración (II)![ref1]**

![](Aspose.Words.2d797eb9-7b4b-4f9e-8341-4c9945bc9673.002.jpeg)

**Florencia Ibarra Freire. Sistemas Informáticos![](Aspose.Words.2d797eb9-7b4b-4f9e-8341-4c9945bc9673.003.jpeg)**

**ÍNDICE![ref1]**

1. [**Introducción.....................................................................................................................................................................................................................................3**](#_page2_x28.35_y28.35)
1. [**Objetivo de la memoria...................................................................................................................................................................................................................3**](#_page2_x28.35_y124.27)
1. [**Material utilizado............................................................................................................................................................................................................................. 3**](#_page2_x28.35_y240.19)
1. [**Desarrollo.........................................................................................................................................................................................................................................4** ](#_page3_x28.35_y44.22)[Ejercicio 1........................................................................................................................................................................................................................................4 ](#_page3_x28.35_y136.33)[Ejercicio 2........................................................................................................................................................................................................................................6 ](#_page5_x28.35_y28.35)[Ejercicio 3........................................................................................................................................................................................................................................7 ](#_page6_x28.35_y28.35)[Ejercicio 4........................................................................................................................................................................................................................................8 ](#_page7_x28.35_y28.35)[Ejercicio 5......................................................................................................................................................................................................................................10](#_page9_x28.35_y28.35)
1. [**Problemas......................................................................................................................................................................................................................................14**](#_page13_x28.35_y28.35)
1. [**Conclusión.....................................................................................................................................................................................................................................14**](#_page13_x28.35_y124.27)

<a name="_page2_x28.35_y28.35"></a>1.Introducción![ref1]

La siguiente práctica nos servirá para realizar las diferentes combinaciones de discos en una unidad lógica, llamada Raid.

Para ello se necesitarán crear varios discos (tantos como nos pida el enunciado) antes de arrancar la máquina para luego poder unirlos según el raid deseado, tanto por interfaz gráfica como en el caso del Raid 1 y con comandos desde la consola de Windows como en el caso del Raid 0.

<a name="_page2_x28.35_y124.27"></a>2.Objetivo de la memoria.

El objetivo de la memoria es aprender a realizar la unión de varios discos para la realización de RAID. En este caso Raid 1 y Raid 0. Se quería hacer también el RAID 5, pero no se pudo ya que es necesario estar conectado a un dominio.

<a name="_page2_x28.35_y240.19"></a>3.Material utilizado

- Ordenador personal
- Aplicación Virtual Box
- OVA de Windows 10 Enterprise
- PDF: 07-Act2\_SOwindows\_Raids

<a name="_page3_x28.35_y44.22"></a>4.Desarrollo![ref1]

**Actividades <a name="_page3_x28.35_y136.33"></a>**Ejercicio 1.

**Como desde un cliente no es posible crear un RAID ![](Aspose.Words.2d797eb9-7b4b-4f9e-8341-4c9945bc9673.004.jpeg)5 (debe estar conectado a un dominio), crea una nuevo volumen RAID 1 en el controlador de dominio con 3 discos de 3GB cada uno (imágenes que lo prueben con el nombre de tu usuario). Si todo ha ido bien pasa al siguiente paso, en caso contrario ¿Explica el motivo por el que no has podido continuar? (una vez explicado avisa al profesor) (imagen/es)** 

Desde la configuración de la máquina virtual vamos a crear 3 discos más con un tamaño de 3GB cada uno, pero para hacer el RAID 1 sólo necesitaremos 2 de ellos. 

Tras ello iremos a la Administración de equipos, ya que se hará de manera gráfica. Seleccionaremos los dos discos que queramos que se reflejen. 

El siguiente paso será asignar la letra de la unidad, pondremos la que queramos, en este caso la E. 

El siguiente paso será formatear el volumen, elegir el sistema de archivos, pondremos![ref1]![](Aspose.Words.2d797eb9-7b4b-4f9e-8341-4c9945bc9673.005.png) como predeterminado el tamaño de la unidad de asignación, nombraremos el nuevo volumen y seleccionaremos donde dice “dar formato rápido”.

⚠ Nos aparecerá un mensaje de advertencia donde nos dice que los discos seleccionados son básicos y que se convertirán en dinámicos y que hay que tener cuidado si tenemos algún sistema operativo instalado en alguno porque se perderá.

Cuando se finalice, nos saldrá que en el equipo tenemos un nuevo disco llamado “DATOS (E:)

<

<a name="_page5_x28.35_y28.35"></a>Ejercicio 2.

**Deposita en el Volumen creado un fichero Nombre+3DNI.txt con tu nombre, la fecha y hora actual, y una frase ingeniosa (imagen)![ref1]**

Aquí creamos el archivo dentro del disco E:![](Aspose.Words.2d797eb9-7b4b-4f9e-8341-4c9945bc9673.006.jpeg) para tener una referencia para el siguiente apartado. (No te rías de la anécdota, Óscar… fue duro cuando me lo contaron)

<a name="_page6_x28.35_y28.35"></a>Ejercicio 3.

**Apaga la MV y desconecta uno de los discos duros que conforman el RAID 1. Arranca de nuevo la MV, inicia sesión con tu usuario y comprueba![ref1] la tolerancia a fallos del volumen abriendo el fichero txt creado. (imagen/es donde se incluya la fecha y hora del equipo en ese instante)**

Tras apagar la máquina y desconectar ![](Aspose.Words.2d797eb9-7b4b-4f9e-8341-4c9945bc9673.007.jpeg)uno de los discos, al querer entrar en el documento antes escrito nos sale un error, ya que el sistema no encuentra la ruta puesto que falta un disco. 

En esta imagen vemos que el Disco 2 falta y que hay errores de redundancia. 

![](Aspose.Words.2d797eb9-7b4b-4f9e-8341-4c9945bc9673.008.png)

<a name="_page7_x28.35_y28.35"></a>Ejercicio 4.

**Repara el volumen RAID 1 y comprueba de nuevo el fichero txt (imagen/es)![ref1]**

En esta imagen ya hemos creado un tercer disco que ![](Aspose.Words.2d797eb9-7b4b-4f9e-8341-4c9945bc9673.009.jpeg)nos arreglará el problema de antes. 

El tercer disco sustituirá el anterior disco dañado. Se le ![](Aspose.Words.2d797eb9-7b4b-4f9e-8341-4c9945bc9673.010.jpeg)asignará una tabla de particiones MBR y lo podremos convertir en un disco dinámico. 

Tras esto se le quitará el error de redundancia al Disco 1 con la opción de “QUITAR REFLEJO” y haremos como antes, agregando el reflejo del Disco 1 al nuevo disco 2. 

Ambos discos comenzarán una sincronización y cuando ya estén listos podremos abrir nuevamente el archivo de antes:


.![](Aspose.Words.2d797eb9-7b4b-4f9e-8341-4c9945bc9673.011.jpeg)![ref1]

<a name="_page9_x28.35_y28.35"></a>Ejercicio 5.

**(optativo)Vuelve a realizar los pasos anteriores pero para un RAID 0 a través de comandos (3 discos de 2GB).![ref1]**

Para crear un RAID 0 desde comandos abriremos la![](Aspose.Words.2d797eb9-7b4b-4f9e-8341-4c9945bc9673.012.jpeg) terminal de Windows y para entrar en la herramienta “DISKPART” escribiremos simplemente esa palabra y ya podremos utilizar los comandos.

Si deseamos ver una lista de los discos que tenemos en el sistema utilizaremos el comando “*list disk”*

Para seleccionar uno de los discos pondremos “*Select disk 1 / 2”* donde se podrá trabajar con cada uno de ellos.

Tras eso, si usamos “*convert dynamic*” podremos convertir los discos básicos en dinámicos.


Para los volúmenes utilizaremos el comando ![ref1]![](Aspose.Words.2d797eb9-7b4b-4f9e-8341-4c9945bc9673.013.jpeg)“*create volume stripe disk = 1,2”* y ahí se nos seleccionarán los dos discos a la vez para crear el volumen. 

Si queremos ver la lista de volúmenes utilizaremos el comando “*list volume”* donde nos saldrán varias columnas con información respecto a cada volumen. 

Seleccionaremos el volumen 4 y le daremos formato y le pondremos![ref1]![](Aspose.Words.2d797eb9-7b4b-4f9e-8341-4c9945bc9673.014.jpeg) el nombre del disco con los siguientes comandos:

“*format fs=ntfs label “*nombre que queramos ponerle” *quick*”

Por último le asignaremos la letra que queramos que lleve con el comando “*assign letter= “E:” “*

![](Aspose.Words.2d797eb9-7b4b-4f9e-8341-4c9945bc9673.015.png)

![](Aspose.Words.2d797eb9-7b4b-4f9e-8341-4c9945bc9673.016.jpeg)

Aquí podemos crear un nuevo archivo en el nuevo disco creado por comandos.![ref1]

He desconectado el disco para hacer lo mismo que antes, pero indagando por Google, ponía que en el RAID 0 no puede ser reparado ya que este tipo de RAID no ofrece redundancia de datos, los datos se distribuyen a través de varios discos sin ningún tipo de duplicación o paridad. Esto significa que si uno de los discos falla, todos los datos del RAID 0 se vuelven inaccesibles e irrecuperables.

<a name="_page13_x28.35_y28.35"></a>5.Problemas![ref1]

En esta ocasión no he encontrado problemas. Externos tal vez, porque mi ordenador es una patata y se ve que al instalar las máquinas virtuales se ralentiza bastante. Deseando estoy de cambiarlo, sólo me falta el dinero.

<a name="_page13_x28.35_y124.27"></a>6.Conclusión

Con esta práctica me he dado cuenta de que es mejor un RAID 1 que un RAID 0 por si se te olvida hacer copias de seguridad constantes, ya que si se estropea uno de los discos, con el RAID 0 no se va a poder acceder a los datos guardados a no ser que se hayan hecho copias en otra unidad, en cambio con el RAID 1, se pueden solucionar esos problemas.

[ref1]: Aspose.Words.2d797eb9-7b4b-4f9e-8341-4c9945bc9673.001.png
